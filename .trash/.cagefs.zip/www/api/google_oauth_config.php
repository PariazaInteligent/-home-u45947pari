<?php
return [
  'client_id'     => '205158128640-79bo86bqu23j1sgsnt67ms4l80886nqi.apps.googleusercontent.com',
  'client_secret' => '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',
  'redirect_uri'  => 'https://pariazainteligent.ro/auth/google/callback.php',
  // 'allowed_hd'  => 'domeniu.ro', // opțional, dacă vrei doar un domeniu GSuite
];

<!DOCTYPE html>
<html lang="ro"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Verifică emailul</title>
<script src="https://cdn.tailwindcss.com"></script>
</head><body class="min-h-screen bg-slate-950 text-slate-100">
<main class="max-w-md mx-auto p-6">
  <h1 class="text-xl font-bold">Verifică emailul</h1>
  <p class="text-slate-400 mt-2 text-sm">Ți-am trimis un link de confirmare. Verifică și folderul Spam.</p>
  <p class="text-xs text-slate-500 mt-4">După confirmare te redirecționăm în dashboard.</p>
</main>
</body></html>
